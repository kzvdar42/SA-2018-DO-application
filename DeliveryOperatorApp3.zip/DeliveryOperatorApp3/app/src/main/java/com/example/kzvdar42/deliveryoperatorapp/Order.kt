package com.example.kzvdar42.deliveryoperatorapp

class Order(var id: Int, var name: String?, var description: String?, var coords: DoubleArray?)
